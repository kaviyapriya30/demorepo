var http=require('http')
var port=3100
http.createServer((req,res)=>{
    res.writeHead(200,({'Content-Type':'text/html'}))
    res.write('<h1>Welcome Everyone</h1>');
    res.end();
    console.log('server created')
}).listen(port)

console.log('welcome');