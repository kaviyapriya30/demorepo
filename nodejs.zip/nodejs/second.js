var cal=require('./calculator.js')
var result=cal.add(10,10)
console.log(`addition of two numbers ${result}`)

var res=cal.sub(600,30)
console.log(`sub of two numbers ${res}`)