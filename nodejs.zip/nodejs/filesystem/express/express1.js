const { application } = require('express')
var express=require('express')

var app=express()

app.set('view engine','html');


app.get('/form',(req,res)=>{
    res.sendFile(__dirname + 'filesystem/express/form.html');
  
})

app.get('/uname/pass',(req,res)=>{
    res.send('<h1>Hai Welcome</h1>')
})
app.get('/name/:id',(req,res)=>{
    var id=req.params.id;
    var name;
   //res.send(id)
    if(id==1)
    {
        name="kaviya"
    }
    else if(id==2){
        name="priya"
    }
    else if(id==3)
    {
        name="raju"
    }
    else{
        name="Girri"
    }
    res.send(`<h1>Hai Welcome ${name} and your id is ${id}</h1>`)
})
app.get('/names',(req,res)=>{
    var id=req.query.id;
    res.send(`<h1> Using query pattern Your id is ${id}</h1>`);
})


app.listen(8081,(req,res)=>{
    console.log('server created')


})
//https://www.youtube.com/watch?v=L9oWG6aj_U8